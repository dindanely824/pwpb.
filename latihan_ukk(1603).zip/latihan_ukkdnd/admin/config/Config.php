<?php

define('baseurl','http://localhost/latihan_ukkdnd/public');