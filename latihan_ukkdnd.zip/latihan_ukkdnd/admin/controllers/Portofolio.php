<?php
 
 class Portofolio extends Controller 
 {
     public function index()
     {
         //kirim parameter ke methid model() yang ada di core/Controller.php
         $data['profile'] = $tihs->model('PortofolioModel.php');

        $this->view('portofolio/index');//menargetkan ke index.php yang ada di folder views/portofolio
     }
 }