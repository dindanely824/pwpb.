<?php 
$koneksi = mysqli_connect("localhost", "root", "", "lat_824");