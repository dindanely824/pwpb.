<?php


define('BASEURL','http://localhost/ujikom_dinda/public/');
